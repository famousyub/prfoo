<?php
	/*
		3W WIT Web Agency
		Teste tecnhique algorithmique sous PHP d'une durée de 1h.
	*/
	
	
	
	
	
	
	$m1 = array();
	/* 
		1-1 	on va remplir une matrice carrée $m1 de taille 8x8 avec des chiffres aléatoire variant entre 100 et 999 
			
		1-2		On affiche la table $array.
			
			résultat attentdu : 
			
				132	252	400	515	125	781	151	912
				250	350	488	552	354	781	161	722
				330	224	481	454	556	781	271	632
				467	550	485	535	758	781	281	542
				532	450	487	509	915	781	391	442
				635	335	477	500	158	781	311	352
				731	380	425	566	598	781	421	262
				831	301	444	555	658	781	431	172
	*/
	
	
	
	
	
	
	
	$diagonal_1 = 0;
	$diagonal_2 = 0;
	$max_val = 0;
	$min_val=0;
	/* 
		2.1 	On va faire une fonction permettant de calculer la somme des chiffres au niveau des deux diagonales de la matrice $m1. 
		2.2 	On va afficher la plus grande et la plus petite valeur de la matrice $m1
	*/
	
	
	
	
	
	$tab = array();
	/* 
		3.1 	soit $tab un tableau de 8 cases. Chaque case N va comporté la somme des chifffres au niveau de la colonne N de la matrice $m1.  
		3.2 	On affiche la table $tab
	*/	
	
	
	
	
	
	
	/*
		5 - ON export le résultat $tab sur un fichier test.CSV avec une seule ligne de 9 colonnes
			https://www.php.net/manual/fr/function.fputcsv.php
	*/
	
	
	
	
	
	
	
	
	
?>